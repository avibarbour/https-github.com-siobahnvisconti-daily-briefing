# Siobhan Visconti Daily Executive Briefing
**Account:** @siobahnvisconti  
**Netlify Project ID:** f2d9f24f-b1e0-41ad-a857-34cdd80c6001  
**Live URL:** https://briefing.siobhanvisconti.com / https://www.siobhanvisconti.com/daily-briefing

## Overview
Luxury daily executive intelligence brief — free to use with attribution.

**Pillars:**
- News: World business & trade, Geopolitics & US-China policy, US politics & fiscal, China property & local finance, Israel & Middle East OPEC
- Sports: NFL, NBA, Formula 1, Premier League, Horse Racing & Breeding
- Pop Culture: Film & prestige TV, Music & culture, Luxury fashion & Siobhan Visconti, Art & auctions, Gaming & Social Media
- Capital Markets: Bitcoin & crypto, China A-shares & Hang Seng, Gold & luxury markets, S&P 500 & Nasdaq, Options/LEAPS
- Macro/Microeconomics

**Branding:**
- Gold SV monogram header, watermark 3.5% opacity, black #000 header, gold #D4AF37 accents
- No emojis per v1.1 skill
- © 2026 Siobhan Visconti, LLC

## License: FREE TO USE WITH ATTRIBUTION
```
This briefing is free to use, share, and republish with attribution.
Required attribution: "Source: Siobhan Visconti Daily Executive Briefing, Siobhan Visconti, LLC - www.siobhanvisconti.com/daily-briefing"
You may quote, share on social, forward to teams, and include in internal memos with credit.
Commercial redistribution allowed with attribution. No removal of watermark or copyright.
```

## Auto-Post Setup
- Meta AI daily task at 8am CT generates fresh briefing artifact + updates index.html
- GitHub Action cron 0 13 * * * (8am CT = 13:00 UTC) triggers Netlify build hook
- Netlify project f2d9f24f-b1e0-41ad-a857-34cdd80c6001 auto-deploys

### Setup Steps (one time)
1. Create repo under @siobahnvisconti: `daily-briefing` or `briefing`
2. Push this repo: git remote add origin https://github.com/siobahnvisconti/daily-briefing.git
3. In Netlify Dashboard > f2d9f24f-b1e0-41ad-a857-34cdd80c6001 > Build hooks > Add hook > Daily 8am CT Briefing > Copy URL
4. In GitHub repo > Settings > Secrets > Add NETLIFY_BUILD_HOOK_URL = hook URL
5. In Netlify > Domain settings > Add custom domain briefing.siobhanvisconti.com

## Local Dev
Open index.html — self-contained with embedded base64 logos, no build needed.

## Daily Content Generation
Meta AI task: Siobhan Visconti Daily - Auto Post Netlify f2d9f24f
Generates luxury artifact daily at 8am CT with free-use license.

## Social Sharing
Permanent URL: https://briefing.siobhanvisconti.com
Caption: "Free daily: Siobhan Visconti Daily Executive Briefing - Free to use with attribution. Source: Siobhan Visconti, LLC - briefing.siobhanvisconti.com"
