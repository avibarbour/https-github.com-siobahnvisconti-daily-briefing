# https-github.com-avibarbour-daily-briefing
Luxury daily executive intelligence brief — free to use with attribution.
